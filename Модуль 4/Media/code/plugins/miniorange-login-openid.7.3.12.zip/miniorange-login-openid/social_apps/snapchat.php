<?php


class mo_snapchat
{
    public $color="#FFFB00";
}