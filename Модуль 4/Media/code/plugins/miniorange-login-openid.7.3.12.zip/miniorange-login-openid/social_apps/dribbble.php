<?php


class mo_dribbble
{
    public $color="#E84C88";
}