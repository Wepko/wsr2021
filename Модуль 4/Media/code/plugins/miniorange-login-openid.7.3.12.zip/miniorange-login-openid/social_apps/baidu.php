<?php


class mo_baidu
{
    public $color="#2112E1";
}