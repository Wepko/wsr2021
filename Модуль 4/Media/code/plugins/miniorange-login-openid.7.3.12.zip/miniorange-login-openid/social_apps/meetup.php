<?php


class mo_meetup
{
    public $color="#EC1C40";
}