<?php
function mo_sl($string){
	 return __($string,'miniorange-login-openid');
 }