![Plugin Banner](https://s3.amazonaws.com/foogallery/foogallery-large.png)

Why choose FooGallery? Stunning gallery layouts, responsive, retina-ready, lightning fast, easy to use.

[FooGallery Homepage](http://fooplugins.com/foogallery/)

[FooGallery on wordpress.org](https://wordpress.org/plugins/foogallery/)
