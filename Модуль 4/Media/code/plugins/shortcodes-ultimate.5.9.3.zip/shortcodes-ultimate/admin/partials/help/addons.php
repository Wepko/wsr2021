<?php defined( 'ABSPATH' ) or exit; ?>

<ul>
	<li><a href="https://getshortcodes.com/docs/how-to-install-add-on/" target="_blank"><?php _e( 'How to install add-on', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="https://getshortcodes.com/docs/updating-premium-add-ons/" target="_blank"><?php _e( 'How to get updates', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="https://getshortcodes.com/docs/how-to-activate-a-license-key/" target="_blank"><?php _e( 'How to activate license key', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="https://getshortcodes.com/docs/#addons" target="_blank"><?php _e( 'Full add-ons documentation', 'shortcodes-ultimate' ); ?></a></li>
</ul>
