<div class="collapse-card custom-css-options-card">
    <div class="title">
        Custom CSS & JavaScript
    </div>
    <div class="body">
        <div class="gks-options-section">
            <br/>
            <textarea id="<?php echo GKSOption::kCustomCSS ?>" placeholder="Enter CSS without using <style></style> tags"></textarea>
            <textarea id="<?php echo GKSOption::kCustomJS ?>" placeholder="Enter JS without using <script></script> tags"></textarea>
        </div>
    </div>
</div>
