<div id="gks-spinner-background">
</div>

<div id="gks-spinner" class="gks-loader gks-loader-large gks-loader-violet gks-loader-delayed">
</div>